

function complete(id) {

    list[id].status = Status.Complete;
    display();


}