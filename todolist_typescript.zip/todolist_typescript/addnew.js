


    function Addnew(){

        var element = document.getElementById('newTask');
        if(element.value){

            var temp = new Entity(element.value);
            list.push(temp);

            display();

        }


    }