enum Status{
    Active , Complete , Delete
}

interface IEntity{
    title :string ;
    status  : string ;
}

class Entity {

    status : number ;

    constructor(public title :string){
        this.status = Status.Active ;
    }


}

var list : Entity[] = [];

var p = new Entity('Java');
var q = new Entity('Javascript');

this.list.push(p);
this.list.push(q);




