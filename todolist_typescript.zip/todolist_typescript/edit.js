

function edit(id ){

        mainId = id ;

        var element = document.getElementById('form2');
        form2.setAttribute('class','show');

        //document.getElementById('field').value= document.getElementById(id).title;

        document.getElementById('field').value =  document.getElementById(id).cells[0].innerText ;


}