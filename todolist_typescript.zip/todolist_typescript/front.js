window.onload = display();

var mainId ;
function display() {

    displayActive();
    displayComplete();
    displayDelete();

}




function displayActive() {
    document.getElementById('form2').setAttribute('class','hide');

    var table = document.getElementById('activeTask');
    table.innerHTML="";
    console.log('In Active');
    for(var p in list){

        if(list[p].status==Status.Active){




            var row = table.insertRow() ;
            row.setAttribute('id',p);

            var titlecell = row.insertCell(0);
            var editcell = row.insertCell(1);
            var deletecell = row.insertCell(2);
            var completecell = row.insertCell(3);
            var button = document.createElement('Button');
            button.innerHTML = 'Edit' ;
            button.setAttribute('onclick','edit('+p+')');
            button.setAttribute('id',p);


            titlecell.innerHTML = list[p].title;
            editcell.appendChild(button);

            var delButton = document.createElement('Button');
            delButton.innerHTML = 'Delete';
            delButton.setAttribute('id',p);
            delButton.setAttribute('onclick','delete2('+p+')');

            var comButton = document.createElement('Button');
            comButton.innerHTML = 'Complete'
            deletecell.appendChild(delButton);
            completecell.appendChild(comButton);
            comButton.setAttribute('id',p);
            comButton.setAttribute('onclick','complete('+p+')');



        }



    }

}


function displayComplete() {

    var element = document.getElementById('completeTask');
    var table = document.createElement('table');
    table.innerHTML="";
    element.innerHTML ='';

    for(var p in list){

        if(list[p].status==Status.Complete){


            var row = table.insertRow();
            var titlecell = row.insertCell(0);
            var buttoncell = row.insertCell(1);
            var button = document.createElement('button');
            button.setAttribute('onclick','delete2('+p+')');
            button.innerHTML = 'Delete';
            titlecell.innerHTML = list[p].title ;
            buttoncell.appendChild(button);

        }


    }

    element.appendChild(table);

}




function displayDelete(){


     var element =  document.getElementById('deleteTask');

    var deletetable = document.createElement('table');
    element.innerHTML ='';
    deletetable.innerHTML="";

     for(var p in list){

        if(list[p].status==Status.Delete){

            var row = deletetable.insertRow() ;
            var cell = row.insertCell(0);
            cell.innerHTML = list[p].title;
        }


     }
     element.appendChild(deletetable);




}




function modify() {
    var element = document.getElementById('newTask');
    element.style.backgroundColor = 'beige' ;

}

function blurred() {
    var element = document.getElementById('newTask');
    element.style.backgroundColor = 'white' ;
}
