

function update(){

    document.getElementById('form2').addEventListener('click',function (event) {

        event.preventDefault();

    var t = new Entity(document.getElementById('field').value);

    list[mainId] = t ;

    displayActive();




    });


}