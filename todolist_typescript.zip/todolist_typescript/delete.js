function delete2(id) {

    list[id].status = Status.Delete ;
    display();
}