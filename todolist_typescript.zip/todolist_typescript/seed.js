var Status;
(function (Status) {
    Status[Status["Active"] = 0] = "Active";
    Status[Status["Complete"] = 1] = "Complete";
    Status[Status["Delete"] = 2] = "Delete";
})(Status || (Status = {}));

var Entity = (function () {
    function Entity(title) {
        this.title = title;
        this.status = 0 /* Active */;
    }
    return Entity;
})();

var list = [];

var p = new Entity('Java');
var q = new Entity('Javascript');

this.list.push(p);
this.list.push(q);
